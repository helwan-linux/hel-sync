import socket

def broadcast_presence(port):
    # وظيفة بتبعت إشارة "أنا هنا" لكل الأجهزة في الشبكة
    pass